import boto3
import json
import os
import uuid
import time
import re

def lambda_handler(event, context):
    print("Evento recebido:", json.dumps(event))
    
    try:
        # Extrair o tema do site e user_id do corpo da requisição
        request_body = json.loads(event.get('body', '{}'))
        site_theme = request_body.get('site_theme', 'site genérico')
        user_id = request_body.get('user_id', str(uuid.uuid4()))
        
        print(f"Tema do site: {site_theme}")
        print(f"User ID: {user_id}")
        
        # Parâmetros do ambiente
        bucket_name = os.environ['BUCKET_NAME']
        model_id = os.environ['MODEL_ID']
        prompt_template = os.environ['HTML_PROMPT_TEMPLATE']
        distribution_id = os.environ['CLOUDFRONT_DISTRIBUTION_ID']
        enable_multi_site = os.environ.get('ENABLE_MULTI_SITE', 'false').lower() == 'true'
        
        # Determinar o caminho do arquivo HTML (sempre usando a estrutura de pastas por usuário)
        # Formato: sites/{user_id}/index.html
        html_path = f"sites/{user_id}/index.html"
        
        # Substituir o placeholder [TEMA] no template do prompt
        prompt = prompt_template.replace('[TEMA]', site_theme)
        
        print(f"Prompt formatado: {prompt}")
        print(f"Caminho do HTML: {html_path}")
        
        # Cliente Bedrock
        bedrock_runtime = boto3.client('bedrock-runtime')
        
        # Preparar o prompt para o modelo (adaptado para Claude)
        if "anthropic" in model_id.lower():
            # Formato para modelos Claude
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 8000,  # Aumentado para permitir HTML mais complexo
                "temperature": 0.7,  # Adicionado para melhor criatividade
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            }
        else:
            # Formato genérico para outros modelos
            request_body = {
                "prompt": prompt,
                "max_tokens": 8000,  # Aumentado para permitir HTML mais complexo
                "temperature": 0.7   # Adicionado para melhor criatividade
            }
        
        print(f"Invocando modelo Bedrock: {model_id}")
        
        # Invocar o modelo Bedrock
        response = bedrock_runtime.invoke_model(
            modelId=model_id,
            body=json.dumps(request_body)
        )
        
        # Processar a resposta com base no modelo
        response_body = json.loads(response['body'].read())
        
        if "anthropic" in model_id.lower():
            # Extração para modelos Claude
            html_content = response_body['content'][0]['text']
        else:
            # Extração genérica para outros modelos
            html_content = response_body.get('completion', response_body.get('generation', ''))
        
        # Verificar se o conteúdo HTML foi gerado
        if not html_content or len(html_content) < 100:
            raise Exception("HTML gerado é muito curto ou vazio")
        
        # Limpar o HTML (remover marcadores de código se presentes)
        # Padrão para extrair código HTML entre marcadores de código
        html_pattern = re.compile(r'```(?:html)?(.*?)```', re.DOTALL)
        match = html_pattern.search(html_content)
        
        if match:
            # Se encontrou o padrão, extrai apenas o conteúdo HTML
            html_content = match.group(1).strip()
        else:
            # Se não encontrou o padrão, verifica se começa com <!DOCTYPE ou <html
            if not (html_content.strip().startswith('<!DOCTYPE') or html_content.strip().startswith('<html')):
                # Se não começa com tags HTML, procura pelo primeiro < que pode indicar o início do HTML
                html_start = html_content.find('<')
                if html_start > 0:
                    html_content = html_content[html_start:].strip()
        
        # Verificar se o HTML contém as tags essenciais
        if not ('<html' in html_content and '</html>' in html_content):
            raise Exception("O conteúdo gerado não parece ser um HTML válido")
        
        print(f"HTML gerado com sucesso ({len(html_content)} caracteres)")
        
        # Cliente S3
        s3 = boto3.client('s3')
        
        # Criar a estrutura de diretórios se necessário
        # Não é necessário criar diretórios explicitamente no S3, mas é uma boa prática
        # verificar se o diretório do usuário já existe
        
        # Salvar o HTML no bucket S3
        s3.put_object(
            Bucket=bucket_name,
            Key=html_path,
            Body=html_content,
            ContentType='text/html'
        )
        
        print(f"HTML salvo com sucesso em s3://{bucket_name}/{html_path}")
        
        # Invalidar o cache do CloudFront
        cloudfront = boto3.client('cloudfront')
        
        invalidation_response = cloudfront.create_invalidation(
            DistributionId=distribution_id,
            InvalidationBatch={
                'Paths': {
                    'Quantity': 1,
                    'Items': ['/' + html_path]
                },
                'CallerReference': str(time.time())
            }
        )
        
        invalidation_id = invalidation_response['Invalidation']['Id']
        print(f"Invalidação do CloudFront iniciada: {invalidation_id}")
        
        # Construir a URL do site
        cloudfront_domain = os.environ.get('CLOUDFRONT_DOMAIN_NAME', f"{distribution_id}.cloudfront.net")
        site_url = f"https://{cloudfront_domain}/{html_path}"
        
        # Retornar resposta de sucesso
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'Site gerado com sucesso',
                'site_url': site_url,
                'site_theme': site_theme,
                'user_id': user_id,
                'invalidation_id': invalidation_id,
                'html_size': len(html_content)  # Adicionado para informação
            })
        }
        
    except Exception as e:
        print(f"Erro: {str(e)}")
        import traceback
        traceback.print_exc()
        
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': f'Erro ao gerar site: {str(e)}'
            })
        }
